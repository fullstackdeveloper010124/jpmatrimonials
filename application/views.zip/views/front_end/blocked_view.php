<div class="container">
	<div class="row">
		<div class="col-md-12 col-xs-12 col-sm-12" style="margin-top:110px;">
			<div class="error-template">
				<h1 style="color:red;font-weight: bold;">Oops!</h1>
				<h3>Your IP is blocked</h3>
				<div class="error-details">Sorry, you can't access more!</div>
			</div>
		</div>
	</div>
</div>