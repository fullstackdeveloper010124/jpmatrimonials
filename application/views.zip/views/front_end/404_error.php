<div class="container container-fluid new-width" id="prt_pref_default">
    <div class="row">
        <div class="col-md-7 col-xs-12 col-sm-12 pr-0">
            <div class="part-pref-box error_box mt-5">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <p class="Poppins-Bold f-34 color-46 error-t1">Oops</p>
                    <p class="Poppins-Regular f-20 color-46 error-t2">Something went wrong... We couldn’t find what you were looking for. You can go back.
                    </p>
                    <div class="mt-10">
                        <a href="javascript:history.back(1);" class="Poppins-Regular f-16 color-f go_back_btn text-center">Go Back</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-5 col-xs-12 col-sm-12 padding-0">
            <div class="error_page_div2">
                <img src="<?php echo $base_url;?>assets/front_end_new/images/404.png" alt="" class="img-responsive error_page">
            </div>
        </div>
    </div>
</div>