

<div class="container margin-top-20">
	<div class="row">
		<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 margin-top-20px padding-lr-zero-320 padding-lr-zero-480 padding-lr-zero-768 padding-0-5-xs">
			<!-- for search side bar-->
			<div class="xxl-4 xl-4 xs-16 m-16 s-16 l-5">
				<div class="xxl-16 xl-16 xs-16 m-16 s-16 l-16  bg-border margin-top-10px hidden-sm hidden-xs" style="margin-bottom: 30px;">
					<div class="row ne-bdr-btm-lgt-grey  ne_com_tab">
						<div class="xxl-16 xl-16 l-16 xs-16 m-16 s-16  margin-top-10px">
							<div class="panel-heading" style="padding:0px;">
								<ul class="nav nav-tabs" style="border-bottom:0px;">
									<li class="active"><a href="#reg" data-toggle="tab">Register Free</a></li>
									<li><a href="#search" data-toggle="tab">Search</a></li>
								</ul>
							</div>
							
						</div>
						
					</div>
					<div class="tab-content xxl-16 xl-16 xs-16 l-16 m-16 s-16">
						<div class="tab-pane fade in active" id="reg">
							<div class=" row form-group  padding-lr-zero-320 padding-lr-zero-480 padding-lr-zero-xs">
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<input type="text" placeholder="First Name" class="form-control input-border padding-new-c" required="">
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<input type="text" placeholder="Last Name" class="form-control input-border padding-new-c" required="">
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<input type="text" placeholder="Email Address" class="form-control input-border padding-new-c" required="">
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<input type="password" placeholder="Password" class="form-control input-border padding-new-c" required="">
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<select name="country_code" id="country_code" class="form-control select2">
										<option value="Select Country Code"> Select Gender</option>
										<option>Male</option>
										<option>Female</option>
									</select>
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16 margin-top-10px">
									<button type="submit" class="btn xxl-16 xl-16 xs-16 m-16 l-16" style="margin-left:0%;">Register</button>
								</div>
							</div>
							
							
						</div>
						<div class="tab-pane fade" id="search">
							<div class=" row form-group  padding-lr-zero-320 padding-lr-zero-480 padding-lr-zero-xs">
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<input type="text" placeholder="First Name" class="form-control padding-new-c input-border" required="">
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<input type="text" placeholder="Last Name" class="form-control padding-new-c input-border" required="">
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<input type="text" placeholder="Email Address" class="form-control padding-new-c input-border" required="">
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<input type="password" placeholder="Password" class="form-control padding-new-c input-border" required="">
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<select name="country_code" id="country_code" class="form-control select2">
										<option value="Select Country Code"> Select Gender</option>
										<option>Male</option>
										<option>Female</option>
									</select>
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16 margin-top-10px">
									<button type="submit" class="btn xxl-16 xl-16 xs-16 m-16 l-16" style="margin-left:0%;">Search</button>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="hidden-sm hidden-xs">
					<div class="religion-matrimonials margin-top-20px">
					
						<h4 class="font1">Religion Matrimonials</h4>
						<hr class="hrmarsetting">
						<div class="listofsection">
							<a href="" title="">
								
								Sikh Matrimony <i class="fa fa-play pull-right play-f"></i>
								
							</a>
							<a href="" title="">
								
								Hindu Matrimony <i class="fa fa-play pull-right play-f"></i>
								
							</a>
							<a href="#" title="">
								
								test1 Matrimony <i class="fa fa-play pull-right play-f"></i>
								
							</a>
							<a href="" title="">
								
								Jain Matrimony <i class="fa fa-play pull-right play-f"></i>
								
							</a>
							<div class="moretag">
								<a href="#" title="">View More</a>
							</div>
						</div>
						
						
					</div>
					<div class="religion-matrimonials margin-top-20px">
						
						<h4 class="font1">Religion Matrimonials</h4>
						<hr class="hrmarsetting">
						<div class="listofsection">
							<a href="" title="">
								
								Sikh Matrimony <i class="fa fa-play pull-right play-f"></i>
								
							</a>
							<a href="" title="">
								
								Hindu Matrimony <i class="fa fa-play pull-right play-f"></i>
								
							</a>
							<a href="#" title="">
								
								test1 Matrimony <i class="fa fa-play pull-right play-f"></i>
								
							</a>
							<a href="" title="">
								
								Jain Matrimony <i class="fa fa-play pull-right play-f"></i>
								
							</a>
							<div class="moretag">
								<a href="#" title="">View More</a>
							</div>
						</div>

						
						
					</div>
					<div class="religion-matrimonials margin-top-20px">
						
						<h4 class="font1">Religion Matrimonials</h4>
						<hr class="hrmarsetting">
						<div class="listofsection">
							<a href="" title="">
								
								Sikh Matrimony <i class="fa fa-play pull-right play-f"></i>
								
							</a>
							<a href="" title="">
								
								Hindu Matrimony <i class="fa fa-play pull-right play-f"></i>
								
							</a>
							<a href="#" title="">
								
								test1 Matrimony <i class="fa fa-play pull-right play-f"></i>
								
							</a>
							<a href="" title="">
								
								Jain Matrimony <i class="fa fa-play pull-right play-f"></i>
								
							</a>
							<div class="moretag">
								<a href="#" title="">View More</a>
							</div>
						</div>
						
						
					</div>
					
				</div>
			</div>
			
			<!-- for search side bar-->
			<!-- for search result -->
			<div class="xxl-12 xl-12 xs-16 m-16 s-16 l-11 ne_myhome_tab ne_com_tab">
				<h3 class="main-title">
					<a href="#" style="color:#000;">Home</a> 
					
					<i class="fa fa-angle-double-right color-black-new"></i>
					
					<a href="http://192.168.1.111/mega_matrimony/original_script/matrimony/sikh-matrimony" style="color:#000;"> 
							
							Sikh Matrimony
							
						</a>  
				</h3>
				<img data-src="http://192.168.1.111/mega_matrimony/original_script/assets/banner/d33980b93b49db00bb1fd640c145b6c1.jpg" class="banner-home-1  img-responsive lazyloaded" src="http://192.168.1.111/mega_matrimony/original_script/assets/banner/d33980b93b49db00bb1fd640c145b6c1.jpg" alt="" style="max-height: 300px;
				width: 100%;">	
				
				<div class="back-img-2">
					<div class="">
						<div class="row">
							<div class="xxl-16 xl-12 xs-16 m-16 s-16 l-16">
								<p> 
									Sikh Matrimony
								</p>
							</div>
						</div>
					</div>
				</div>
				<div class="xxl-16 xl-16 xs-16 m-16 s-16 l-16  bg-border margin-top-20px hidden-lg hidden-md" style="margin-bottom: 30px;">
					<div class="row ne-bdr-btm-lgt-grey  ne_com_tab">
						<div class="xxl-16 xl-16 l-16 xs-16 m-16 s-16  margin-top-10px">
							<div class="panel-heading" style="padding:0px;">
								<ul class="nav nav-tabs" style="border-bottom:0px;">
									<li class="active"><a href="#reg-m" data-toggle="tab">Register Free</a></li>
									<li><a href="#search-m" data-toggle="tab">Search</a></li>
								</ul>
							</div>
							
						</div>
						
					</div>
					<div class="tab-content xxl-16 xl-16 xs-16 l-16 m-16 s-16" style="margin-top:23px;">
						<div class="tab-pane fade in active" id="reg-m">
							<div class=" row form-group  padding-lr-zero-320 padding-lr-zero-480 padding-lr-zero-xs">
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<input type="text" placeholder="First Name" class="form-control padding-new-c input-border" required="">
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<input type="text" placeholder="Last Name" class="form-control  padding-new-c input-border" required="">
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<input type="text" placeholder="Email Address" class="form-control padding-new-c input-border" required="">
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<input type="password" placeholder="Password" class="form-control padding-new-c input-border" required="">
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<select name="country_code" id="country_code" class="form-control select2">
										<option value="Select Country Code"> Select Gender</option>
										<option>Male</option>
										<option>Female</option>
									</select>
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16 margin-top-10px">
									<button type="submit" class="btn xxl-16 xl-16 xs-16 m-16 l-16" style="margin-left:0%;">Register</button>
								</div>
							</div>
							
							
						</div>
						<div class="tab-pane fade" id="search-m">
							<div class=" row form-group  padding-lr-zero-320 padding-lr-zero-480 padding-lr-zero-xs">
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<input type="text" placeholder="First Name" class="form-control padding-new-c input-border" required="">
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<input type="text" placeholder="Last Name" class="form-control padding-new-c input-border" required="">
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<input type="text" placeholder="Email Address" class="form-control padding-new-c input-border" required="">
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<input type="password" placeholder="Password" class="form-control padding-new-c input-border" required="">
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16">
									<select name="country_code" id="country_code" class="form-control select2">
										<option value="Select Country Code"> Select Gender</option>
										<option>Male</option>
										<option>Female</option>
									</select>
								</div>
								<div class="xxl-16 xs-16 m-12 l-12 xl-12 s-16 margin-top-10px">
									<button type="submit" class="btn xxl-16 xl-16 xs-16 m-16 l-16" style="margin-left:0%;">Search</button>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="xxl-16 xl-12 xs-16 m-16 s-16 l-16">
						<h1 class="comm-h2">
						Sikh Matrimony </h1>
						<hr style="margin-top:5px;margin-bottom:10px">
						<p class="cmmup">One of India's best known brands and the world's largest matrimonial service was founded with a simple objective - to help people find happiness. The company pioneered online matrimonials in 1996 and continues to lead the exciting matrimony category.</p>
					</div>
				</div>
				<div class="row">
					<div class="xxl-16 xl-16 xs-16 l-16 m-16 s-16 padding-lr-zero-320 padding-lr-zero-480 margin-top-10px-320px margin-top-10px-480px ne-mrg-top-10-768 padding-lr-zero-768 padding-0-5-xs">
						<div class="xxl-16 xl-16 xs-16 l-16 m-16 s-16 padding-15px bg-border">
							<div class="row">
								<div class="xxl-16 xl-16 l-16 xs-16 m-16 s-16  margin-top-10px">
									<div class="panel-heading">
										<ul class="nav nav-tabs">
											<li class="active"><a href="#tab1primary" data-toggle="tab">Sikh <b>Female</b></a></li>
											<li><a href="#tab2primary" data-toggle="tab">Sikh <b>Male</b></a></li>
											
											
										</ul>
									</div>
									
								</div>
								
							</div>
							
							<div class="clearfix"></div>
							<div class="tab-content" style="background: transparent;
							border:0;
							box-shadow:none;">
								
								<div class="tab-pane fade in active" id="tab1primary">
									<div class="xs-16 xl-16 xxl-16 m-16 s-16 ne_result padding-lr-zero">
										<div class="row">
											<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 ne">
												<div class="">
													<div class="xxl-1 xl-1 l-1 m-1 s-16 xs-16">
														&nbsp;<!--<input type="checkbox" class="pull-left" name="m_status" value="Unmarried">-->
													</div>
													<h2 id="mobile_hover" class="margin-top-0px margin-bottom-0px xxl-5 xl-5 l-5 m-5 s-16 xs-16" style="padding:0px;">
														<a target="_blank" href="http://192.168.1.111/mega_matrimony/original_script/search/view-profile/NE411519" class="name-title xxl-16 xl-16 l-16 m-16 s-16 xs-16 padding-lr-zero ne_font_weight_nrm"> Female &nbsp;<span class="user-id">(NE411519)</span>
															<!--<span class="mobile-status"  data-toggle="tooltip" title="Contact Available" ></span>
															<span class="horo-status"  data-toggle="tooltip" title="Horoscope Available"></span>-->
														</a>
													</h2>
													
												</div>
											</div>
										</div>
										<hr>
										<div class="xxl-4 xxl-margin-left-0 xl-4 xl-margin-left-0 xs-12 xs-margin-left-2 l-4 l-margin-left-0 m-5 m-margin-left-0">
											
											<a target="_blank" href="http://192.168.1.111/mega_matrimony/original_script/search/view-profile/NE411519">
												<img src="http://192.168.1.111/mega_matrimony/original_script/assets/front_end/img/default-photo/male.png" class="img-responsive ne_result_img myimg" title="fedaf egeg" alt="NE411519" style="height:164px!important;weight:164px!important;">
											</a>
											<p class="small text-center margin-top-5">
												
												<a target="_blank" href="http://192.168.1.111/mega_matrimony/original_script/search/view-profile/NE411519" class="underline">View Full Details</a>
											</p>
											
											<ul class="xxl-16 xl-16 m-16 xs-16 l-16 s-16 padding-lr-zero margin-top-10px margin-bottom-10px neResultBottomIcons"></ul>
										</div> 
										
										<div class="xxl-12 xl-12 l-12 m-11 s-16 xs-16 padding-lr-zero-1199 padding-lr-zero-999 padding-lr-zero-768">
											<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 margin-top-10px ne-bdr-btm-lgt-grey ne">
												<div class="row">
													<div class="xxl-10 xl-10 l-10 m-16 s-16 xs-16">
														<div class="row">
															<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 ne_font_12 margin-bottom-6px">
																<div class="row">
																	<div class="xxl-6 xl-6 l-6 m-6 s-6 ne_mrg_ri8_10">
																		<div class="row label-title">
																			Age / Height
																		</div>
																	</div>
																	<div class="xxl-9 xl-9 l-9 m-9 s-9 ne-word-wrap">
																		<div class="row">
																		: 18 Years, N/A                                    </div>
																	</div>
																</div>
															</div>
															
															<div class="clearfix"></div>
															<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 ne_font_12 margin-bottom-6px">
																<div class="row">
																	<div class="xxl-6 xl-6 l-6 m-6 s-6 ne_mrg_ri8_10">
																		<div class="row label-title">
																			Religion
																		</div>
																	</div>
																	<div class="xxl-9 xl-9 l-9 m-9 s-9 ne-word-wrap">
																		<div class="row">
																		: Ishai                                    </div>
																	</div>
																</div>
															</div>
															<div class="clearfix"></div>
															<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 ne_font_12 margin-bottom-6px">
																<div class="row">
																	<div class="xxl-6 xl-6 l-6 m-6 s-6 ne_mrg_ri8_10">
																		<div class="row label-title">
																			Caste
																		</div>
																	</div>
																	<div class="xxl-9 xl-9 l-9 m-9 s-9 ne-word-wrap">
																		<div class="row">
																		: Ishai Caste                                    </div>
																	</div>
																</div>
															</div>
															<div class="clearfix"></div>
															<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 ne_font_12 margin-bottom-6px">
																<div class="row">
																	<div class="xxl-6 xl-6 l-6 m-6 s-6 ne_mrg_ri8_10">
																		<div class="row label-title">
																			Mother Tongue
																		</div>
																	</div>
																	<div class="xxl-9 xl-9 l-9 m-9 s-9 ne-word-wrap">
																		<div class="row">
																		: N/A                                    </div>
																	</div>
																</div>
															</div>
															<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 ne_font_12 margin-bottom-6px">
																<div class="row">
																	<div class="xxl-6 xl-6 l-6 m-6 s-6 ne_mrg_ri8_10">
																		<div class="row label-title">
																			Education
																		</div>
																	</div>
																	<div class="xxl-9 xl-9 l-9 m-9 s-9 ne-word-wrap">
																		<div class="row">
																		:                                     </div>
																	</div>
																</div>
															</div>
															<div class="clearfix"></div>
															<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 ne_font_12 margin-bottom-6px">
																<div class="row">
																	<div class="xxl-6 xl-6 l-6 m-6 s-6 ne_mrg_ri8_10">
																		<div class="row label-title">
																			Location
																		</div>
																	</div>
																	<div class="xxl-9 xl-9 l-9 m-9 s-9 ne-word-wrap">
																		<div class="row">
																		: N/A, N/A, N/A                                    </div>
																	</div>
																</div>
															</div>
															<div class="clearfix"></div>
															<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 ne_font_12 margin-bottom-6px">
																<div class="row">
																	<div class="xxl-6 xl-6 l-6 m-6 s-6 ne_mrg_ri8_10">
																		
																		<div class="row label-title">
																			Occupation
																		</div>
																	</div>
																	<div class="xxl-9 xl-9 l-9 m-9 s-9 ne-word-wrap">
																		<div class="row">
																		: N/A                                    </div>
																	</div>
																</div>
															</div>
														</div>       
													</div>
													
													
													<div class="xxl-6 xl-6 l-6 m-16 s-16 xs-16  border-left">
														<div class="row text-center" style="">
															<h3>
																<span id="like_unlike_NE411519">
																Like/Unlike            </span>
																Him Profile?
															</h3>
															
															<a id="Yes_id_NE411519" style="display:inline-block;" href="javascript:;" class="profile-complate-btn-like-unlike" onclick="member_like('Yes','NE411519');"><i class="fa fa-thumbs-up ne_mrg_ri8_10"></i>Like</a>
															<a id="Image_Yes_NE411519" style="display:none">
																<i class="fa fa-thumbs-up ne_mrg_ri8_10" style="font-size:25px;color:rgba(49,33,248,0.95);"></i>
															</a>
															<!--<a href="#" class="profile-complate-skip btn-sm" title="May be" style="background:#83E1ED !important;color:#fff !important;">May be</a>-->
															<a id="No_id_NE411519" style="display:inline-block;" href="javascript:;" onclick="member_like('No','NE411519');" class="profile-complate-btn-like-unlike"><i class="fa fa-thumbs-down ne_mrg_ri8_10"></i>Unlike</a>
															<a id="Image_No_NE411519" style="display:none;">
																<i class="fa fa-thumbs-down ne_mrg_ri8_10" style="font-size:25px;color:rgba(49,33,248,0.95);"></i>
															</a>
															
															<div class="clearfix"></div>
															<div class="margin-top-5"></div>
															
															
															
															<a href="javascript:;" class="">
																<i class="fa fa-thumbs-up" style="font-size:20px; color:rgba(49,33,248,0.95);"></i> 
																<span id="total_likesNE411519" class="count badge badge-info" style="font-size:15px;">0					</span>
															</a>
															
															<a href="javascript:;" class="">
																<i class="fa fa-thumbs-down" style="font-size:20px; color:rgba(49,33,248,0.95);"></i>
																<span id="total_unlikesNE411519" class="count badge badge-info" style="font-size:15px;">0</span>
															</a>
															
															<!--<a href="search/view-profile/" class="small padding-lr-zero" title="view Profile">
																<img src="assets/front_end/images/icon/viewprofile-icon.gif" alt="viewprofile-icon" /> <span class="underline">View full Profile</span>
															</a>-->
														</div>
													</div>
													
												</div>
											</div>
											<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 margin-top-5">
												<div class="row">
													<p class="small">
													N/A<a target="_blank" href="http://192.168.1.111/mega_matrimony/original_script/search/view-profile/NE411519">Read More</a> <img src="http://192.168.1.111/mega_matrimony/original_script/assets/front_end/images/icon/view-arrow.gif" alt="view-arrow"></p>
												</div>
											</div>
										</div>
										<div class="clearfix"></div>
										<hr style="margin:5px 0px; !important;">
										<div style="text-align: center">
											<a class="underline hook1 in" data-toggle="collapse" href=".NE411519" aria-expanded="false">More Details <i class="fa fa-chevron-down"></i></a>
										</div>
										
										
										<div class="clearfix"></div>
										<input type="hidden" id="matri_id_for_action" name="matri_id_for_action" value="">
										<div class="collapse hook1 margin-top-10 NE411519">
											<div class="xxl-16 xl-16 l-16 m-16" align="center">
												<span><h3>If you want to know more details about this member please login.</h3></span>
											</div>
										</div>
										<div class="clearfix"></div>	
									</div>
								</div>
								<div class="tab-pane fade" id="tab2primary">
									<div class="xs-16 xl-16 xxl-16 m-16 s-16 ne_result padding-lr-zero">
										<div class="row">
											<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 ne">
												<div class="">
													<div class="xxl-1 xl-1 l-1 m-1 s-16 xs-16">
														&nbsp;<!--<input type="checkbox" class="pull-left" name="m_status" value="Unmarried">-->
													</div>
													<h2 id="mobile_hover" class="margin-top-0px margin-bottom-0px xxl-5 xl-5 l-5 m-5 s-16 xs-16" style="padding:0px;">
														<a target="_blank" href="http://192.168.1.111/mega_matrimony/original_script/search/view-profile/NE411519" class="name-title xxl-16 xl-16 l-16 m-16 s-16 xs-16 padding-lr-zero ne_font_weight_nrm">Male&nbsp;<span class="user-id">(NE411519)</span>
															<!--<span class="mobile-status"  data-toggle="tooltip" title="Contact Available" ></span>
															<span class="horo-status"  data-toggle="tooltip" title="Horoscope Available"></span>-->
														</a>
													</h2>
													
												</div>
											</div>
										</div>
										<hr>
										<div class="xxl-4 xxl-margin-left-0 xl-4 xl-margin-left-0 xs-12 xs-margin-left-2 l-4 l-margin-left-0 m-5 m-margin-left-0">
											
											<a target="_blank" href="http://192.168.1.111/mega_matrimony/original_script/search/view-profile/NE411519">
												<img src="http://192.168.1.111/mega_matrimony/original_script/assets/front_end/img/default-photo/male.png" class="img-responsive ne_result_img myimg" title="fedaf egeg" alt="NE411519" style="height:164px!important;weight:164px!important;">
											</a>
											<p class="small text-center margin-top-5">
												
												<a target="_blank" href="http://192.168.1.111/mega_matrimony/original_script/search/view-profile/NE411519" class="underline">View Full Details</a>
											</p>
											
											<ul class="xxl-16 xl-16 m-16 xs-16 l-16 s-16 padding-lr-zero margin-top-10px margin-bottom-10px neResultBottomIcons"></ul>
										</div> 
										
										<div class="xxl-12 xl-12 l-12 m-11 s-16 xs-16 padding-lr-zero-1199 padding-lr-zero-999 padding-lr-zero-768">
											<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 margin-top-10px ne-bdr-btm-lgt-grey ne">
												<div class="row">
													<div class="xxl-10 xl-10 l-10 m-16 s-16 xs-16">
														<div class="row">
															<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 ne_font_12 margin-bottom-6px">
																<div class="row">
																	<div class="xxl-6 xl-6 l-6 m-6 s-6 ne_mrg_ri8_10">
																		<div class="row label-title">
																			Age / Height
																		</div>
																	</div>
																	<div class="xxl-9 xl-9 l-9 m-9 s-9 ne-word-wrap">
																		<div class="row">
																		: 18 Years, N/A                                    </div>
																	</div>
																</div>
															</div>
															
															<div class="clearfix"></div>
															<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 ne_font_12 margin-bottom-6px">
																<div class="row">
																	<div class="xxl-6 xl-6 l-6 m-6 s-6 ne_mrg_ri8_10">
																		<div class="row label-title">
																			Religion
																		</div>
																	</div>
																	<div class="xxl-9 xl-9 l-9 m-9 s-9 ne-word-wrap">
																		<div class="row">
																		: Ishai                                    </div>
																	</div>
																</div>
															</div>
															<div class="clearfix"></div>
															<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 ne_font_12 margin-bottom-6px">
																<div class="row">
																	<div class="xxl-6 xl-6 l-6 m-6 s-6 ne_mrg_ri8_10">
																		<div class="row label-title">
																			Caste
																		</div>
																	</div>
																	<div class="xxl-9 xl-9 l-9 m-9 s-9 ne-word-wrap">
																		<div class="row">
																		: Ishai Caste                                    </div>
																	</div>
																</div>
															</div>
															<div class="clearfix"></div>
															<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 ne_font_12 margin-bottom-6px">
																<div class="row">
																	<div class="xxl-6 xl-6 l-6 m-6 s-6 ne_mrg_ri8_10">
																		<div class="row label-title">
																			Mother Tongue
																		</div>
																	</div>
																	<div class="xxl-9 xl-9 l-9 m-9 s-9 ne-word-wrap">
																		<div class="row">
																		: N/A                                    </div>
																	</div>
																</div>
															</div>
															<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 ne_font_12 margin-bottom-6px">
																<div class="row">
																	<div class="xxl-6 xl-6 l-6 m-6 s-6 ne_mrg_ri8_10">
																		<div class="row label-title">
																			Education
																		</div>
																	</div>
																	<div class="xxl-9 xl-9 l-9 m-9 s-9 ne-word-wrap">
																		<div class="row">
																		:                                     </div>
																	</div>
																</div>
															</div>
															<div class="clearfix"></div>
															<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 ne_font_12 margin-bottom-6px">
																<div class="row">
																	<div class="xxl-6 xl-6 l-6 m-6 s-6 ne_mrg_ri8_10">
																		<div class="row label-title">
																			Location
																		</div>
																	</div>
																	<div class="xxl-9 xl-9 l-9 m-9 s-9 ne-word-wrap">
																		<div class="row">
																		: N/A, N/A, N/A                                    </div>
																	</div>
																</div>
															</div>
															<div class="clearfix"></div>
															<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 ne_font_12 margin-bottom-6px">
																<div class="row">
																	<div class="xxl-6 xl-6 l-6 m-6 s-6 ne_mrg_ri8_10">
																		
																		<div class="row label-title">
																			Occupation
																		</div>
																	</div>
																	<div class="xxl-9 xl-9 l-9 m-9 s-9 ne-word-wrap">
																		<div class="row">
																		: N/A                                    </div>
																	</div>
																</div>
															</div>
														</div>       
													</div>
													
													
													<div class="xxl-6 xl-6 l-6 m-16 s-16 xs-16  border-left">
														<div class="row text-center" style="">
															<h3>
																<span id="like_unlike_NE411519">
																Like/Unlike            </span>
																Him Profile?
															</h3>
															
															<a id="Yes_id_NE411519" style="display:inline-block;" href="javascript:;" class="profile-complate-btn-like-unlike" onclick="member_like('Yes','NE411519');"><i class="fa fa-thumbs-up ne_mrg_ri8_10"></i>Like</a>
															<a id="Image_Yes_NE411519" style="display:none">
																<i class="fa fa-thumbs-up ne_mrg_ri8_10" style="font-size:25px;color:rgba(49,33,248,0.95);"></i>
															</a>
															<!--<a href="#" class="profile-complate-skip btn-sm" title="May be" style="background:#83E1ED !important;color:#fff !important;">May be</a>-->
															<a id="No_id_NE411519" style="display:inline-block;" href="javascript:;" onclick="member_like('No','NE411519');" class="profile-complate-btn-like-unlike"><i class="fa fa-thumbs-down ne_mrg_ri8_10"></i>Unlike</a>
															<a id="Image_No_NE411519" style="display:none;">
																<i class="fa fa-thumbs-down ne_mrg_ri8_10" style="font-size:25px;color:rgba(49,33,248,0.95);"></i>
															</a>
															
															<div class="clearfix"></div>
															<div class="margin-top-5"></div>
															
															
															
															<a href="javascript:;" class="">
																<i class="fa fa-thumbs-up" style="font-size:20px; color:rgba(49,33,248,0.95);"></i> 
																<span id="total_likesNE411519" class="count badge badge-info" style="font-size:15px;">0					</span>
															</a>
															
															<a href="javascript:;" class="">
																<i class="fa fa-thumbs-down" style="font-size:20px; color:rgba(49,33,248,0.95);"></i>
																<span id="total_unlikesNE411519" class="count badge badge-info" style="font-size:15px;">0</span>
															</a>
															
															<!--<a href="search/view-profile/" class="small padding-lr-zero" title="view Profile">
																<img src="assets/front_end/images/icon/viewprofile-icon.gif" alt="viewprofile-icon" /> <span class="underline">View full Profile</span>
															</a>-->
														</div>
													</div>
													
												</div>
											</div>
											<div class="xxl-16 xl-16 l-16 m-16 s-16 xs-16 margin-top-5">
												<div class="row">
													<p class="small">
													N/A<a target="_blank" href="http://192.168.1.111/mega_matrimony/original_script/search/view-profile/NE411519">Read More</a> <img src="http://192.168.1.111/mega_matrimony/original_script/assets/front_end/images/icon/view-arrow.gif" alt="view-arrow"></p>
												</div>
											</div>
										</div>
										<div class="clearfix"></div>
										<hr style="margin:5px 0px; !important;">
										<div style="text-align: center">
											<a class="underline hook1 in" data-toggle="collapse" href=".NE411519" aria-expanded="false">More Details <i class="fa fa-chevron-down"></i></a>
										</div>
										
										
										<div class="clearfix"></div>
										<input type="hidden" id="matri_id_for_action" name="matri_id_for_action" value="">
										<div class="collapse hook1 margin-top-10 NE411519">
											<div class="xxl-16 xl-16 l-16 m-16" align="center">
												<span><h3>If you want to know more details about this member please login.</h3></span>
											</div>
										</div>
										<div class="clearfix"></div>	
									</div>
								</div>
							</div>
							<div class="xxl-16 xl-16 l-16 m-16 xs-16 s-16 tp-pagination margin-top-20">
								<!-- for pagination-->
								<div class="col-md-12 tp-pagination"><ul id="ajax_pagin_ul" class="pagination"><li class="active"><a href="#">1</a></li><li><a href="http://192.168.1.111/mega_matrimony/original_script/search/result/2" data-ci-pagination-page="2">2</a></li><li><a href="http://192.168.1.111/mega_matrimony/original_script/search/result/3" data-ci-pagination-page="3">3</a></li><li class="next page ci-pagination-next"><a href="http://192.168.1.111/mega_matrimony/original_script/search/result/2" data-ci-pagination-page="2" rel="next">Next</a></li><li class="next page ci-pagination-next"><a href="http://192.168.1.111/mega_matrimony/original_script/search/result/6" data-ci-pagination-page="6">Last ›</a></li></ul></div><!-- for pagination-->
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
				<div class="hidden-lg hidden-md">
					<div class="">
						<div class="religion-matrimonials margin-top-20px ">
							<button type="button" class="btn btn-block btn-lg  btn-matry" data-toggle="collapse" data-target="#demo">Community Matrimonial <i class="fa fa-caret-down pull-right"></i></button>
							
							<div id="demo" class="collapse">	
								<div class="listofsection">
									<a href="" title="">
										
										Sikh Matrimony <i class="fa fa-play pull-right play-f"></i>
										
									</a>
									<a href="" title="">
										
										Hindu Matrimony <i class="fa fa-play pull-right play-f"></i>
										
									</a>
									<a href="#" title="">
										
										test1 Matrimony <i class="fa fa-play pull-right play-f"></i>
										
									</a>
									<a href="" title="">
										
										Jain Matrimony <i class="fa fa-play pull-right play-f"></i>
										
									</a>
									<div class="moretag">
										<a href="#" title="">View More</a>
									</div>
								</div>
							</div>
							
						</div>
						<div class="religion-matrimonials margin-top-10px">
							<button type="button" class="btn btn-block btn-lg  btn-matry" data-toggle="collapse" data-target="#demo-2">Community Matrimonial <i class="fa fa-caret-down pull-right"></i></button>
							
							<div id="demo-2" class="collapse">	
								<div class="listofsection">
									<a href="" title="">
										
										Sikh Matrimony <i class="fa fa-play pull-right play-f"></i>
										
									</a>
									<a href="" title="">
										
										Hindu Matrimony <i class="fa fa-play pull-right play-f"></i>
										
									</a>
									<a href="#" title="">
										
										test1 Matrimony <i class="fa fa-play pull-right play-f"></i>
										
									</a>
									<a href="" title="">
										
										Jain Matrimony <i class="fa fa-play pull-right play-f"></i>
										
									</a>
									<div class="moretag">
										<a href="#" title="">View More</a>
									</div>
								</div>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<br>
<br>																																																																																																																	