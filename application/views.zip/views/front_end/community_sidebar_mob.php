<div class="list-group">
                    <a class="list-group-item google-plus" href="#">
                        <p class="Poppins-Semi-Bold f-16 color-d dashbrd_1">
                            Caste Matrimonials
                        </p>
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-16 color-38 dashbrd_3">
                            Jain Matrimony
                        </p>
                        <span class="Poppins-Semi-Bold f-16 color-38 dashbrd_4"><i class="fas fa-caret-right"></i></span>
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-16 color-38 dashbrd_3">
                            Ishai Matrimony
                        </p>
                        <span class="Poppins-Semi-Bold f-16 color-38 dashbrd_4"><i class="fas fa-caret-right"></i></span>
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-16 color-38 dashbrd_3">
                            Buddhist Matrimony
                        </p>
                        <span class="Poppins-Semi-Bold f-16 color-38 dashbrd_4"><i class="fas fa-caret-right"></i></span>
                    </a>
    <a class="list-group-item visitor" href="#">
        <p class="Poppins-Medium f-16 color-38 dashbrd_3">
            Hindu Matrimony
        </p>
        <span class="Poppins-Semi-Bold f-16 color-38 dashbrd_4"><i class="fas fa-caret-right"></i></span>
    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-15 color-d text-right color-38 dashbrd_3 text-right">
                            View More  
                        </p>
                        
                    </a>
                </div>

                <div class="list-group">
                    <a class="list-group-item google-plus" href="#">
                        <p class="Poppins-Semi-Bold f-16 color-d dashbrd_1">
                            Caste Matrimonials
                        </p>
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-16 color-38 dashbrd_3">
                            Jain Matrimony
                        </p>
                        <span class="Poppins-Semi-Bold f-16 color-38 dashbrd_4"><i class="fas fa-caret-right"></i></span>
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-16 color-38 dashbrd_3">
                            Ishai Matrimony
                        </p>
                        <span class="Poppins-Semi-Bold f-16 color-38 dashbrd_4"><i class="fas fa-caret-right"></i></span>
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-16 color-38 dashbrd_3">
                            Buddhist Matrimony
                        </p>
                        <span class="Poppins-Semi-Bold f-16 color-38 dashbrd_4"><i class="fas fa-caret-right"></i></span>
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-16 color-38 dashbrd_3">
                            Hindu Matrimony
                        </p>
                        <span class="Poppins-Semi-Bold f-16 color-38 dashbrd_4"><i class="fas fa-caret-right"></i></span>
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-15 color-d text-right color-38 dashbrd_3 text-right">
                            View More  
                        </p>
                        
                    </a>
                </div>
                
                
                <div class="list-group">
                    <a class="list-group-item google-plus" href="#">
                        <p class="Poppins-Semi-Bold f-16 color-d dashbrd_1">
                            Country Matrimonials
                            
                        </p>
                        
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-16 color-38 dashbrd_3">
                            Jain Matrimony
                        </p>
                        <span class="Poppins-Semi-Bold f-16 color-38 dashbrd_4"><i class="fas fa-caret-right"></i></span>
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-16 color-38 dashbrd_3">
                            Ishai Matrimony
                        </p>
                        <span class="Poppins-Semi-Bold f-16 color-38 dashbrd_4"><i class="fas fa-caret-right"></i></span>
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-16 color-38 dashbrd_3">
                            Buddhist Matrimony
                        </p>
                        <span class="Poppins-Semi-Bold f-16 color-38 dashbrd_4"><i class="fas fa-caret-right"></i></span>
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-16 color-38 dashbrd_3">
                            Hindu Matrimony
                        </p>
                        <span class="Poppins-Semi-Bold f-16 color-38 dashbrd_4"><i class="fas fa-caret-right"></i></span>
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-15 color-d text-right color-38 dashbrd_3 text-right">
                            View More  
                        </p>
                        
                    </a>
                </div>
                
						
                <div class="list-group">
                    <a class="list-group-item google-plus" href="#">
                        <p class="Poppins-Semi-Bold f-16 color-d dashbrd_1">
                            Mother Tongue Matrimonials
                        </p>
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-16 color-38 dashbrd_3">
                            Jain Matrimony
                        </p>
                        <span class="Poppins-Semi-Bold f-16 color-38 dashbrd_4"><i class="fas fa-caret-right"></i></span>
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-16 color-38 dashbrd_3">
                            Ishai Matrimony
                        </p>
                        <span class="Poppins-Semi-Bold f-16 color-38 dashbrd_4"><i class="fas fa-caret-right"></i></span>
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-16 color-38 dashbrd_3">
                            Buddhist Matrimony
                        </p>
                        <span class="Poppins-Semi-Bold f-16 color-38 dashbrd_4"><i class="fas fa-caret-right"></i></span>
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-16 color-38 dashbrd_3">
                            Hindu Matrimony
                        </p>
                        <span class="Poppins-Semi-Bold f-16 color-38 dashbrd_4"><i class="fas fa-caret-right"></i></span>
                    </a>
                    <a class="list-group-item visitor" href="#">
                        <p class="Poppins-Medium f-15 color-d text-right color-38 dashbrd_3 text-right">
                            View More  
                        </p>
                        
                    </a>
				</div>
			</div>