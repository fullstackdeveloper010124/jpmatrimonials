<p class="Poppins-Regular f-14 color-40 reg-caption-1 pt-4">Why register with us ?</p>
<div class="reg-img-box mt-5">
    <div class="row">
        <div class="col-md-2">
            <div class="bg-reg_icon1"></div>
        </div>
        <div class="col-md-10">
            <p class="Poppins-Regular f-14 color-40 img-t1">All the profiles are verified personally
            </p>
        </div>
    </div>
</div>
<div class="reg-img-box mt-5">
    <div class="row">
        <div class="col-md-2">
            <div class="bg-reg_icon2"></div>
        </div>
        <div class="col-md-10">
            <p class="Poppins-Regular f-14 color-40 img-t1">
                Search best profiles for best matches
            </p>
        </div>
    </div>
</div>
<div class="reg-img-box mt-5">
    <div class="row">
        <div class="col-md-2">
            <div class="bg-reg_icon3"></div>
        </div>
        <div class="col-md-10">
            <p class="Poppins-Regular f-14 color-40 img-t1">Looking for Safe & secure matrimony service?
            </p>
        </div>
    </div>
</div>