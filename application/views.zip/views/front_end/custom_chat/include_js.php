<script src="<?php echo $base_url;?>assets/custom_chat/js/custom_chat.js?ver=<?php echo filemtime('assets/custom_chat/js/custom_chat.js');?>"></script>

